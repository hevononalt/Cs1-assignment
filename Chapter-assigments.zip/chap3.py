def sum_squares():

    pass

def factorial():

    pass

def sumtorial():

    pass

# Assignment starts here
def sum_squares (l):
    curn_num = 0
    for n in list (l):
        curn_num = curn_num + n ** 2
    return curn_num

print (sum_squares([3, 13, 4, 7]))

def factorial(l):
    curn_num = 1
    for n in range(1, l + 1):
        curn_num = curn_num * n
    return curn_num

print(factorial(6))

def sumtorial(l):
    sum_num = 0
    for n in range(1, l + 1):
        sum_num = sum_num + n
    return sum_num

print(sumtorial(6))

def fib(l):
    a = 1
    b = 1
    c = 1
    for n in range(l):
        c = a
        a = b
        b = c + b   
    return c

print(fib(3))

def trib(l):
    a = 0
    b = 0
    c = 1
    for n in range(l):
        d = a + b + c
        a = b
        b = c
        c = d
    return a

print(trib(12))
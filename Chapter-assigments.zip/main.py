# this is for the first part of the assignmet(A)
Fahrenheit =  0
Celsius = round((Fahrenheit - 32) * 5/9, 2)
print("A tempreture of 0 degrees Fahrenheit is equivalent to", Celsius, "degrees celsius.")

# this is for the seccond part of the assignment
Fahrenheit = 100
print("While a Tempreture of 100 degrees Fahrenheit is equivalent to", Celsius, "degrees celsius.")

# this is for the third part of the assignment
age_in_years = 15
secs_in_min = 60
mins_in_hour = 60
hours_in_day = 24
days_in_year = 365
age_in_secs = age_in_years * days_in_year * hours_in_day * mins_in_hour * secs_in_min
print("I am", age_in_years, "years old. This is equivalent to", age_in_secs, "seconds.")

# this is for the dog's age.
age_in_years = 9
age_in_secs = age_in_years * days_in_year * hours_in_day * mins_in_hour * secs_in_min
print("My dog is", age_in_years, "years old. This is equivalent to", 
 age_in_secs, "seconds.")

#This is for the radius section.
radius = 6
PI = 3.14159265358
Sph_Vol = round(4/3 * PI * (radius ** 3), 2)
print("the Volume fo a sphere with a radius of 6 is", Sph_Vol, "Cubed")
radius = 18
Sph_SA = round(4 * PI * (radius ** 2), 2)
print("the surface area of a sphere with a radius of 18 is", Sph_SA, "squared")

#This is for the third digit.
an_int = 13579
thrd_int = an_int // 100 % 10 # the // 100 is for getting rid of the first 2 digist
print("the third digit of", an_int, "is", thrd_int)
another_int = 246810
thrd_int = another_int // 100 % 10
print("the third digit of", another_int, "is", thrd_int)

# And Finaly, this is for the input radius.
num_sides = int(input("What is the number of sides? "))
Sph_Vol = round(4/3 * PI * (num_sides ** 3), 2)
print("the volume of a sphere with a radius of", num_sides,"is", Sph_Vol ,"cubed")